# Massiv-Chat

Die App enthält:
- Chat mit Massiv
- lokale Chat-Historie
- Sprachaufnahme mit Wiedergabe
- Kamera-Vorschau
- Datei-Auswahl
- Antwort vorlesen
- Piano

## Echte KI-Antworten

Das Frontend ruft `/api/chat` auf. Der API-Key liegt ausschließlich als Server-Umgebungsvariable.

Für einen Vercel-Deploy:
1. Repository importieren.
2. Environment Variable `OPENAI_API_KEY` setzen.
3. Optional `OPENAI_MODEL` setzen.
4. Deploy.

GitHub Pages allein kann `/api/chat` nicht ausführen; dafür braucht die App einen Server/Serverless-Host.
